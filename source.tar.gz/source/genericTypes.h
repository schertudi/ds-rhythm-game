#pragma once

struct Colour {
    int r;
    int g;
    int b;
};

struct Vec2d {
    int x;
    int y;
};